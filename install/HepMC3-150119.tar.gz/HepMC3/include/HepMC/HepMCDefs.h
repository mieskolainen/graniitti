// -*- C++ -*-
//
// This file is part of HepMC
// Copyright (C) 2014-2015 The HepMC collaboration (see AUTHORS for details)
//
#ifndef HEPMC_DEFS_H
#define HEPMC_DEFS_H

#include "HepMC/Version.h"
#include "HepMC/Config.h"
#warning "HepMC/HepMCDefs.h is deprecated: please #include HepMC/Config.h instead (or not at all)"

#endif
