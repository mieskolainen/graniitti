#ifdef __CINT__

#pragma link C++ class MyClass+;
#pragma link C++ class MyRunClass+;
#pragma link C++ class HepMC::GenEvent-;
#pragma link C++ class HepMC::GenRunInfo-;

#endif
